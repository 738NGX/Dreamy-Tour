/*
 * 小程序相关的常量类
 * @Author: Franctoryer 
 * @Date: 2025-02-28 14:06:39 
 * @Last Modified by: Franctoryer
 * @Last Modified time: 2025-03-01 18:33:16
 */
class AppConstant {
  static readonly APP_ID = "wx6c0d5ae365e9b82d";
  static readonly APP_SECRET = "4dc9a166948e23b1a347abbfe8ecbda0";
}

export default AppConstant;