export enum Currency { CNY, USD, EUR, JPY, HKD, MOP, TWD, GBP, KRW, SGD, THB, RUB, CAD, INR, AUD, VND };

class TourConstant {
  
}

export default TourConstant;